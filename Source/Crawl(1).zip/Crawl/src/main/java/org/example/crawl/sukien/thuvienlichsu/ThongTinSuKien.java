package org.example.crawl.sukien.thuvienlichsu;

import org.example.crawl.sukien.base.AThongTinSuKien;
import org.example.model.NhanVat;
import org.example.model.SuKien;
import org.example.model.UniqueID;
import org.example.util.TienIch;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ThongTinSuKien extends AThongTinSuKien {
    private Document htmlPage;
    private String source;
    public ThongTinSuKien() {

    }

    @Override
    public SuKien layThongTinSuKien(String source) {
        SuKien suKien = new SuKien();
        this.source = source;
        htmlPage = layHTML();
        if(htmlPage == null) {
            System.out.println("Không load được html page");
            return null;
        }

        String tenSuKien = layTenSuKien();
        suKien.setTenSuKien(tenSuKien);
        suKien.setUrlPath(source);
        suKien.setIdSuKien(UniqueID.getIdSuKien());
        ArrayList<String> batDauKetThuc = layNamBatDauKetThuc(tenSuKien);
        suKien.setThoiDiemBatDau(batDauKetThuc.get(0));
        suKien.setThoiDiemKetThuc(batDauKetThuc.get(1));
        suKien.setMoTa(layMota());
        suKien.setNhanVatLienQuan(layNhanVatLienQuan());

        return suKien;
    }


    private ArrayList<Integer> layNhanVatLienQuan() {
        ArrayList<Integer> nhanVatLienQuan = new ArrayList<>();
        Elements elements = htmlPage.select(".divide-tag");

        for(Element temp: elements) {
            Element headerElement = temp.selectFirst("h3.header-edge");
            String title = headerElement.text().trim();
            if(title.toLowerCase().contains("nhân vật liên quan")) {
                Elements listNV = temp.select(".card-body .card-title");
                for(Element nhanVat: listNV) {
                    String titleText = nhanVat.text();
                    if(titleText.contains("(")) {
                        titleText = titleText.substring(0, titleText.indexOf("("));
                    }

                    titleText = titleText.trim();
                    int idNV = NhanVat.getIDNhanVat(titleText);
                    if(idNV >= 0) {
                        nhanVatLienQuan.add(idNV);
                    }
                    //System.out.printf("Ten NV: %s ID NV: %d\n", titleText, NhanVat.getIDNhanVat(titleText));

                }
            }
        }



        return nhanVatLienQuan;
    }
    private ArrayList<String> layNamBatDauKetThuc(String text) {
        ArrayList<String> namSinhMat = new ArrayList<>();
        Pattern p = Pattern.compile("\\(-?[\\d\\s].*\\)");
        Matcher m = p.matcher(text);
        if (m.find()) {
            String[] listTime = m.group(0).replaceAll("\\(", "").replaceAll("\\)", "").split(" - ");
            if(listTime.length >= 2) {
                namSinhMat.add(listTime[0].trim());
                namSinhMat.add(listTime[1].trim());
            } else if(listTime.length >= 1) {
                namSinhMat.add(listTime[0].trim());
                namSinhMat.add(null);
            }
            return namSinhMat;
        }

        namSinhMat.add(null);
        namSinhMat.add(null);
        return namSinhMat;
    }
    private String layTenSuKien() {
        String result = null;
        Element element = htmlPage.selectFirst("body > div.wrap > div.container.pt-7 > div:nth-child(2) > div.col-12.col-md-8 > div:nth-child(2) > div > div.divide-line > h3");
        if(element != null) {
            result = element.text().trim();
        }
        return result;
    }
    private String layMota() {
        String result = null;
        Element element = htmlPage.selectFirst("body > div.wrap > div.container.pt-7 > div:nth-child(2) > div.col-12.col-md-8 > div:nth-child(3) > div > div.card-body");
        if(element != null) {
            result = element.text().trim();
        }
        return result;
    }

    private Document layHTML() {
        try {
            return Jsoup.connect(source).get();
        } catch (IOException e) {
            System.out.println("Request Time Out");
            e.printStackTrace();
        }

        return null;
    }
}