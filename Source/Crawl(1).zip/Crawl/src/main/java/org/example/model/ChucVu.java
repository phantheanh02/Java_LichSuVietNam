package org.example.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class ChucVu {
    private String ten;
    private String taiVi;
    private String tienNhiem;
    private String keNhiem;
    private String nhiemKy;
    @Override
    public String toString() {
        return "\nChức vụ: " + ten +
                "\nTại vị: " + taiVi +
                "\nTiền nhiệm: " + tienNhiem +
                "\nKế nhiệm: " + keNhiem +
                "\nNhiệm kỳ: " + nhiemKy;
    }
}

