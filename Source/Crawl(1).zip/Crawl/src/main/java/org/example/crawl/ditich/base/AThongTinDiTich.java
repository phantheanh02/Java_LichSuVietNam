package org.example.crawl.ditich.base;

import org.example.model.DiTich;
import org.example.model.NhanVat;

public abstract class AThongTinDiTich {
    public  abstract DiTich layThongTinNhanVat(String tenDiTich);
}
