package org.example.crawl.lehoi.base;

import org.example.model.LeHoi;
import org.example.model.NhanVat;

public abstract class AThongTinLeHoi {
    public  abstract LeHoi layThongTinLeHoi(String tenleHoi);
}
