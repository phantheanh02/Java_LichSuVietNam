package org.example.controller;

import org.example.crawl.lehoi.wikipedia.DanhSachTenLeHoi;

public class LeHoiController {
    public void start() {
        DanhSachTenLeHoi danhSanhTenLeHoi = new DanhSachTenLeHoi();
        danhSanhTenLeHoi.danhSachLeHoi();
    }
}
