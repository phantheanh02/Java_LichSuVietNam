package org.example.model;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.example.util.TienIch;

import java.util.ArrayList;
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter

public class ThoiKy {
    private int idThoiKy;
    private String tenThoiKy;
    private String thoiGianBatDau;
    private String thoiGianKetThuc;
    private String moTa;
    private ArrayList<String> hinhAnh = new ArrayList<>();

    public static ThoiKy getByID(int ID) {
        ThoiKy thoiKy = new ThoiKy();
        if(!TienIch.checkFileExist("output/thoiky.json")) {
            return null;
        }
        JavaType type = new ObjectMapper().getTypeFactory().constructCollectionType(ArrayList.class, ThoiKy.class);
        ArrayList<ThoiKy> listThoiKy = TienIch.loadJson(type, "output/thoiky.json");
        if(listThoiKy == null) {
            return null;
        }

        for(int i = 0; i < listThoiKy.size(); i++) {
            if(listThoiKy.get(i).getIdThoiKy() == ID) {
                return listThoiKy.get(i);
            }
        }

        return null;
    }
}
