package org.example.crawl.ditich.Wikipedia;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.crawl.ditich.base.ADanhSachDiTich;
import org.example.model.DiTich;
import org.example.model.UniqueID;
import org.example.util.TienIch;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;

public class DanhSachDiTichLichSu extends ADanhSachDiTich {

    private Document htmlPages;
    private ArrayList<DiTich> danhSachDiTich;
    private String contentData;
    private String diTichOutput = "output/di_tich.json";
    public DanhSachDiTichLichSu() {
        danhSachDiTich = new ArrayList<>();
        layHTML();
    }

    @Override
    public ArrayList<DiTich> layDanhSachDiTich() {
        System.out.println("Lưu dữ liệu di tích lịch sử");
        Elements listTrElements = htmlPages.select("table.wikitable.sortable > tbody > tr");
        for(Element temp: listTrElements) {
            Elements tdElement = temp.select("> td");
            if(tdElement.size() <= 0) {
                continue;
            }
            DiTich diTich = new DiTich();
            String tenDiTich = layTen(tdElement.get(0));
            if(tenDiTich == null || tenDiTich.isEmpty() || tenDiTich.compareToIgnoreCase("Di tích") == 0) {
                continue;
            }

            System.out.printf("Xử lý di tích: %s\n", tenDiTich);
            String linkTitle = null;
            String moTa = null;
            String hinhAnh = null;
            try {
                linkTitle = tdElement.get(0).selectFirst("> a").attr("title");
                contentData = TienIch.loadJsonTuUrl(TienIch.layDuongDanWikiApiTuTenDoiTuong(linkTitle));
                hinhAnh = layAnh();
                moTa = layMoTa();
            } catch (NullPointerException e) {
                e.printStackTrace();
            }


            String diaDiem = layDiaDiem(tdElement.get(2));
            diTich.setTen(tenDiTich);
            diTich.setId(UniqueID.getIdDiTich());
            diTich.setDiaDiem(diaDiem);
            diTich.setHinhAnh(hinhAnh);
            diTich.setMoTa(moTa);
            danhSachDiTich.add(diTich);
            TienIch.luuJson(diTichOutput, danhSachDiTich);
            System.out.printf("\tHoàn thành xử lý di tích: %s\n", tenDiTich);
        }
        return danhSachDiTich;
    }

    private void layHTML(){
        try {
            htmlPages = Jsoup.connect("https://vi.wikipedia.org/wiki/Di_t%C3%ADch_qu%E1%BB%91c_gia_%C4%91%E1%BA%B7c_bi%E1%BB%87t_(Vi%E1%BB%87t_Nam)").get();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private String layTen(Element source) {
        String htmlText = source.html();
        if(htmlText.contains("<sup")) {
            htmlText = htmlText.substring(0, htmlText.indexOf("<sup"));
        }

        Document doc = Jsoup.parse(htmlText);
        if(doc.text().isEmpty())
            return null;
        return doc.text();
    }

    private String layDiaDiem(Element source) {
        String htmlText = source.html();
        if(htmlText.contains("<sup")) {
            htmlText = htmlText.substring(0, htmlText.indexOf("<sup"));
        }

        if(htmlText.contains("<span")) {
            htmlText = htmlText.substring(0, htmlText.indexOf("<span"));
        }
        Document doc = Jsoup.parse(htmlText);
        if(doc.text().isEmpty())
            return null;
        return doc.text();
    }

    private String layMoTa() {
        String extract = null;
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode extractNode;
        //Trong 1 số trường hợp, 1 vài link lễ hội chưa được cập nhật thông tin trên wiki mà chỉ có trang trắng, hoặc đường dẫn bằng bên bị sai cú pháp (lỗi do web)
        //vì vậy json sẽ không có cấu trúc thông thường của wikiApi. Do đó sẽ xảy ra hiện tượng đường dẫn là null khi truy cập vào các trường, từ đó gây ra lỗi
        try {
            JsonNode rootNode = objectMapper.readTree(contentData);
            JsonNode pagesNode = rootNode.path("query").path("pages").get(0);
            //Nếu pagesNode khác null thì tiếp tục select và trường "extract"
            if (pagesNode != null) {
                extractNode = pagesNode.path("extract");
                extract = extractNode.asText();
            }
        } catch (JsonProcessingException e) {
            // Log error or do something else
            return null;
        }
        return extract;
    }

    private String layAnh() {
        String img = null;
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode extractNode;
        //Trong 1 số trường hợp, 1 vài link lễ hội chưa được cập nhật thông tin trên wiki mà chỉ có trang trắng, hoặc đường dẫn bằng bên bị sai cú pháp (lỗi do web)
        //vì vậy json sẽ không có cấu trúc thông thường của wikiApi. Do đó sẽ xảy ra hiện tượng đường dẫn là null khi truy cập vào các trường, từ đó gây ra lỗi
        try {
            JsonNode rootNode = objectMapper.readTree(contentData);
            JsonNode pagesNode = rootNode.path("query").path("pages").get(0);
            //Nếu pagesNode khác null thì tiếp tục select vào trường "source"
            if (pagesNode != null) {
                extractNode = pagesNode.path("thumbnail").path("source");
                img = extractNode.asText();
            }
        } catch (JsonProcessingException e) {
            // Log error or do something else
            return null;
        }
        return img;
    }


}
