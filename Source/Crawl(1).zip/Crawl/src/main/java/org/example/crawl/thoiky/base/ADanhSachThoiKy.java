package org.example.crawl.thoiky.base;

import org.example.model.ThoiKy;

import java.util.ArrayList;

public abstract class ADanhSachThoiKy {
    public abstract ArrayList<ThoiKy> layDanhSachThoiKy();
}
