package org.example.crawl.sukien.thuvienlichsu;

import org.example.crawl.sukien.base.ADanhSachSuKien;
import org.example.model.SuKien;
import org.example.model.UniqueID;
import org.example.util.TienIch;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;

public class DanhSachSuKien extends ADanhSachSuKien {
    ArrayList<SuKien> listSuKien = new ArrayList<>();

    @Override
    public void layDanhSachSuKien() {
        System.out.println("Danh sach su kien");
        for(int i = 1; i <= 19; i++) {
            System.out.printf("Bắt đầu lấy danh sách sự kiện trang %d:\n", i);
            String url = "https://thuvienlichsu.com/su-kien?page=" + i;
            try {
                Document document = Jsoup.connect(url).get();
                Elements listElements = document.select("div > div.card");
                for(Element temp: listElements) {
                    Element linkElement = temp.selectFirst(".card-body > a");
                    if(linkElement == null) {
                        continue;
                    }
                    SuKien sukien = new SuKien();
                    sukien.setUrlPath("https://thuvienlichsu.com" + linkElement.attr("href"));
                    Element imageElement = temp.selectFirst(".col-md-4 img");
                    if(imageElement != null) {
                        sukien.setImage("https://thuvienlichsu.com" + imageElement.attr("src"));
                    }
                    listSuKien.add(sukien);
                    TienIch.luuJson("output/sukien.json", listSuKien);
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                e.printStackTrace();
            }
            System.out.printf("\tHoàn tất lấy danh sách sự kiện trang %d:\n", i);
        }

    }

}