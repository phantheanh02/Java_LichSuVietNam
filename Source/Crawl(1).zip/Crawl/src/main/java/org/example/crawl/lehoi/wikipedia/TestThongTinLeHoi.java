package org.example.crawl.lehoi.wikipedia;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import org.example.util.TienIch;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TestThongTinLeHoi {

    public static Document htmlPage;

    public static void main(String[] args) throws IOException {
        layHTML();
        try {
            layLeHoiCacTinhThanh();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        layThongTinLeHoi();
    }

    /**
     * Lấy đường dẫn HTML
     */
    public static void layHTML() {
        try {
            htmlPage = Jsoup.connect("https://vi.wikipedia.org/wiki/L%E1%BB%85_h%E1%BB%99i_Vi%E1%BB%87t_Nam?fbclid=IwAR3l4Ciwtp4ZVF6yMgnwKZ4cy4pLVVB1jFj5DtjT0G5FcAjtQJEhCRrSO74#Danh_s%C3%A1ch_m%E1%BB%99t_s%E1%BB%91_l%E1%BB%85_h%E1%BB%99i").get();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void layLeHoiCacTinhThanh() throws IOException {
        Elements leHoiCacTinhThanh = htmlPage.select("#mw-content-text > div.mw-parser-output > ul:nth-child(27) > li");
        for (Element tmp : leHoiCacTinhThanh) {
            System.out.println(tmp.text());
        }
    }

    public static void layThongTinLeHoi() throws IOException {
        String thongTinLeHoi = null;
        int index = 0;
        Elements thongTinLeHois = htmlPage.select("#mw-content-text > div.mw-parser-output > table.prettytable.wikitable > tbody > tr");
        for (Element tmp : thongTinLeHois) {
            if (index++ < 1) continue;
            Elements thuocTinhLeHois = tmp.select(" > td");
            int index1 = 0;
            for (Element thuocTinhLeHoi : thuocTinhLeHois) {
                if (index1++ > 2) break;
                else {
                    System.out.println(index1+ "\t\t" + thuocTinhLeHoi.text());
                    if(index1 == 3){
                        Element linkMoTa = thuocTinhLeHoi.selectFirst("> a");
                        if (linkMoTa == null) System.out.println("\t\t null");
                        else {
                            String moTa = linkMoTa.attr("href").substring(6);
                            thongTinLeHoi = layMoTa(TienIch.layDuongDanWikiApiTuTenDoiTuong(moTa));
                            System.out.println(thongTinLeHoi);
                            thongTinLeHoi = layAnh(TienIch.layDuongDanWikiApiTuTenDoiTuong(moTa));
                            System.out.println(thongTinLeHoi);
                        }
                    }
                }
                System.out.println();
            }
        }
    }

    private static String layJsonData(String url) {
        // Tạo request
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .build();
        Response response = null;
        try {
            response = client.newCall(request).execute();
            return response.body().string();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private static String layMoTa(String url) {
        String extract = null;
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode extractNode;
        try {
            JsonNode rootNode = objectMapper.readTree(layJsonData(url));
            JsonNode pagesNode = rootNode.path("query").path("pages").get(0);
            if (pagesNode != null) {
                extractNode = pagesNode.path("extract");
                extract = extractNode.asText();
            }
        } catch (JsonProcessingException e) {
            // Log error or do something else
            return null;
        }
        return extract;
    }

    private static String layAnh(String url) {
        String img = null;
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode imgNode;
        //Trong 1 số trường hợp, 1 vài link lễ hội chưa được cập nhật thông tin trên wiki mà chỉ có trang trắng, hoặc đường dẫn bằng bên bị sai cú pháp (lỗi do web)
        //vì vậy json sẽ không có cấu trúc thông thường của wikiApi. Do đó sẽ xảy ra hiện tượng đường dẫn là null khi truy cập vào các trường, từ đó gây ra lỗi
        try {
            JsonNode rootNode = objectMapper.readTree(layJsonData(url));
            JsonNode pagesNode = rootNode.path("query").path("pages").get(0);
            //Nếu pagesNode khác null thì tiếp tục select và trường "extract"
            if (pagesNode != null) {
                imgNode = pagesNode.path("thumbnail").path("source");
                img = imgNode.asText();
            }
        } catch (JsonProcessingException e) {
            // Log error or do something else
            return null;
        }
        return img;
    }
}