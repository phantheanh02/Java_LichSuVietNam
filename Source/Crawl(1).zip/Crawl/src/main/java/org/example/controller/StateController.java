package org.example.controller;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.model.StateCrawl;
import org.example.util.TienIch;

import java.io.File;

public class StateController {
    private String stateFilePath = "save_state/state.json";

    public static void main(String[] args) {
        StateController state = new StateController();
        StateCrawl current = state.loadProgress();
    }

    public StateController() {
        TienIch.taoFile(stateFilePath);
    }

    public StateCrawl loadProgress() {
        JavaType type = new ObjectMapper().getTypeFactory().constructType(StateCrawl.class);
        var data = TienIch.<StateCrawl>loadJson(type, stateFilePath);
        if(data == null) {
            return new StateCrawl(0, 0);
        }
        return data;
    }

    public void saveProgress(StateCrawl state) {
        TienIch.luuJson(stateFilePath, state);
    }

    public void restartState() {
        saveProgress(new StateCrawl(0, 0));
    }
}
