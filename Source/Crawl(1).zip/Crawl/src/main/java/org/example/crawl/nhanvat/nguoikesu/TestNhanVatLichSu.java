package org.example.crawl.nhanvat.nguoikesu;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.example.util.TienIch.*;

public class TestNhanVatLichSu {
    public static String tenNhanVatNks, tenNhanVatWiki;
    public static String regexCha1 = "Cha (.*?)[\\,\\.]";
    public static String regexMe1 = "mẹ là (.*?)[\\,\\.]";
    public static String regexMe2 = "mẹ ông là (.*?)[\\,\\.]";

    public static String regexCha_Wiki = "cha =(.*?)\\n";
    public static String regexMe_Wiki = "mẹ =(.*?)\\n";





    public static void main(String[] args) {
        String ten_url, wikiAPI_url;
        for (int i = 1; i <= 10; i++) {
            int start = i * 5 - 5;
            System.out.println("Page: " + i);
            ten_url = "https://nguoikesu.com/nhan-vat?start=" + start;
            try {
                layTenNhanVat(ten_url);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

    }


    public static void layTenNhanVat(String url) throws IOException {
        Document document = Jsoup.connect(url).get();
        Elements nhanVat = document.select("#content > div.com-content-category-blog.blog > div.com-content-category-blog__items.blog-items > div ");
        for (Element tmp : nhanVat) {
            Element tenNhanVat = tmp.select("> div > div > h2 > a").first();
            tenNhanVatNks = tenNhanVat.text();
            System.out.println(tenNhanVatNks);
//            System.out.println("\t\t" + tenNhanVat.text() + ": " + tenNhanVat.attr("abs:href"));
            tenNhanVatWiki = tenNhanVatNks.replace(' ', '_');

            layThongTinNhanVat(tenNhanVat.attr("abs:href"));
            try {
                layThongTinChaMe(tenNhanVat.attr("abs:href"));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            layThongTinChaWikiApi(layDuongDanWikiApiTuTenNV(tenNhanVatNks));
            System.out.println(getLinkImage());
            System.out.println(getExtract());
        }
    }

    /*
        Lấy thông tin nhân vật chủ yếu lấy từ phần thẻ "table" chứa thông tin cơ bản của wiki, bên trang người kể sử cũng có nhưng cx chỉ là copy từ wiki sang
     */
    public static void layThongTinNhanVat(String url){
        Document document = null;
        try {
            document = Jsoup.connect(url).get();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        Elements thongTinNhanVat = document.select("#content > div.com-content-article.item-page.page-list-items > div.com-content-article__body > div.infobox > table > tbody > tr");
        for (Element tmp : thongTinNhanVat) {
            // thẻ th ghi thuộc tính, thẻ td chứa nội dung thuộc tính
            Elements thongTin_td = tmp.select("> td ");
            Elements thongTin_td_ul_li = thongTin_td.select(" ul > li ");
            Element thuocTinhNhanVat = tmp.select("> th").first();
            if (thuocTinhNhanVat == null) continue;
            else {
                if (thuocTinhNhanVat.text().compareToIgnoreCase("thân phụ") == 0 || thuocTinhNhanVat.text().compareToIgnoreCase("thân mẫu") == 0 || thuocTinhNhanVat.text().compareToIgnoreCase("cha") == 0 || thuocTinhNhanVat.text().compareToIgnoreCase("mẹ") == 0) {
                    System.out.print(thuocTinhNhanVat.text());
                    if (thongTin_td_ul_li.size() == 0) System.out.println("\t\t\t\t" + thongTin_td.text());
//                    else {
//                        for (Element trieuDai : thongTin_td_ul_li) {
//                            System.out.println("\t\t" + trieuDai.text());
//                        }
//                    }
                }
            }
        }

        System.out.println("############################################################################################################");
    }

    // Lấy thông tin cha mẹ từ các thẻ <p> trong page
    public static void layThongTinChaMe(String url) throws IOException {
        Document document = Jsoup.connect(url).get();
        Elements layThongTinTuTheP = document.select("#content > div.com-content-article.item-page.page-list-items > div.com-content-article__body p");
        for (Element tmp : layThongTinTuTheP) {
            layThongTinChaP(tmp.text());
            layThongTinMeP(tmp.text());
        }
    }

    //Lấy thông tin cha mẹ từ wiki api ( chỉ duyệt các trường có cấu trúc sau: " cha = ... \n "

    public static Request requestWikiApi(String url){
        Request request = new Request.Builder()
                .url(url)
                .get()
                .build();
        return request;
    }

    /**
     * Lấy nội dung phần content trong wikiAPI
     * @param url
     * @return
     * @throws IOException
     */
    public static String getContentWikiApi(String url) throws IOException {
        String content = null;

        OkHttpClient client = new OkHttpClient();
        try (Response response = client.newCall(requestWikiApi(url)).execute()) {
            if (!response.isSuccessful()) {
                throw new IOException("Unexpected code " + response);
            }
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode contentNode = objectMapper.readTree(response.body().string())
                    .path("query").path("pages").get(0).path("revisions").get(0).path("slots").path("main").path("content");
            content = contentNode.asText();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return content;
    }
    public static void layThongTinChaWikiApi(String url) {
        String father = null;
        // t để hai trường hợp duyệt tìm từ khóa "Cha" và "cha" nhằm so sánh kết quả và khả năng khớp (từ khóa "cha" tỉ lệ 100% so vs "Cha")
        Pattern pattern1 = Pattern.compile(regexCha_Wiki);
        Matcher matcher1 = null;
        try {
            matcher1 = pattern1.matcher(getContentWikiApi(url));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        if (matcher1.find()) {
            father = matcher1.group(1);
            System.out.println("Cha3 = " + father);
        }
    }

    public static void layThongTinMeWikiApi(String url) throws IOException {
        String father = null;
        // t để hai trường hợp duyệt tìm từ khóa "Cha" và "cha" nhằm so sánh kết quả và khả năng khớp (từ khóa "cha" tỉ lệ 100% so vs "Cha")
        Pattern pattern = Pattern.compile(regexMe_Wiki);
        Matcher matcher = pattern.matcher(getContentWikiApi(url));
        if (matcher.find()) {
            father = matcher.group(1);
            System.out.println("Mẹ3 = " + father);
        }
    }

    public static void layThongTinChaP(String text) throws IOException {
        String father = null;
        Pattern pattern1 = Pattern.compile(regexCha1);
        Matcher matcher1 = pattern1.matcher(text);
        if (matcher1.find()) {
            father = matcher1.group(1);
            System.out.println("Cha0 = " + father);
        }
    }

    public static void layThongTinMeP(String text) throws IOException {
        String father = null;
        // t để hai trường hợp duyệt tìm từ khóa "Cha" và "cha" nhằm so sánh kết quả và khả năng khớp (từ khóa "Cha" đưa ra thông tin chính xác hơn so với "cha")
        Pattern pattern1 = Pattern.compile(regexMe1);
        Matcher matcher1 = pattern1.matcher(text);
        Pattern pattern2 = Pattern.compile(regexMe2);
        Matcher matcher2 = pattern2.matcher(text);
        if (matcher1.find()) {
            father = matcher1.group(1);
            System.out.println("Mẹ0 = " + father);
        }
        if (matcher2.find()) {
            father = matcher2.group(1);
            System.out.println("Mẹ1 = " + father);
        }
    }
    //câu lệnh regular expression tìm cha mẹ trên API wiki: /cha(.*?)=(.*?)\\n/gm (áp dụng trên wiki api) hoặc Cha (.*?)[\,\.] (áp dụng trên các thẻ <p> của page)

    public static String getLinkImage(){
        String img = null;
        OkHttpClient client = new OkHttpClient();
        try (Response response = client.newCall(requestWikiApi(layDuongDanWikiApiTuTenNV(tenNhanVatNks))).execute()) {
            if (!response.isSuccessful()) {
                throw new IOException("Unexpected code " + response);
            }
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode sourceNode = objectMapper.readTree(response.body().string())
                    .path("query").path("pages").get(0).path("thumbnail").path("source");
             img = sourceNode.asText();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return img;
    }

    public static String getExtract(){
        String extract = null;
        OkHttpClient client = new OkHttpClient();
        try (Response response = client.newCall(requestWikiApi(layDuongDanWikiApiTuTenNV(tenNhanVatNks))).execute()) {
            if (!response.isSuccessful()) {
                throw new IOException("Unexpected code " + response);
            }
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode extractNode = objectMapper.readTree(response.body().string())
                    .path("query").path("pages").get(0).path("extract");
            extract = extractNode.asText();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return extract;
    }
}
