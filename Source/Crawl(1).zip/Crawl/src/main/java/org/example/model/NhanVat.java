package org.example.model;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.example.util.TienIch;

import java.util.ArrayList;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor

public class NhanVat {
    private int idNhanVat;
    private String tenNhanVat;
    private String namSinh;
    private String namMat;
    private String tenCha;
    private String tenMe;

    private ArrayList<ChucVu> chucVu;
    private ArrayList<Integer> idThoiKy;
    private String urlPath;
    private String image;
    private String description;

    public static int getIDNhanVat(String tenNhanVat) {
        int result = -1;

        if(!TienIch.checkFileExist("output/nhan_vat.json")) {
            return result;
        }
        JavaType type = new ObjectMapper().getTypeFactory().constructCollectionType(ArrayList.class, NhanVat.class);
        var data = TienIch.<ArrayList<NhanVat>>loadJson(type, "output/nhan_vat.json");
        for(NhanVat temp: data) {
            if(temp.getTenNhanVat().toLowerCase().contains(tenNhanVat.toLowerCase())) {
                return temp.getIdNhanVat();
            }
        }
        return result;
    }

    public static NhanVat getByID(int ID) {
        NhanVat nhanVat = new NhanVat();
        if(!TienIch.checkFileExist("output/nhan_vat.json")) {
            return null;
        }
        JavaType type = new ObjectMapper().getTypeFactory().constructCollectionType(ArrayList.class, NhanVat.class);
        ArrayList<NhanVat> listNhanVat = TienIch.loadJson(type, "output/nhan_vat.json");
        if(listNhanVat == null) {
            return null;
        }

        for(int i = 0; i < listNhanVat.size(); i++) {
            if(listNhanVat.get(i).getIdNhanVat() == ID) {
                return listNhanVat.get(i);
            }
        }

        return null;
    }
    @Override
    public String toString() {
        return "NhanVat{" +
                "idNhanVat=" + idNhanVat +
                ", tenNhanVat='" + tenNhanVat + '\'' +
                ", namSinh='" + namSinh + '\'' +
                ", namMat='" + namMat + '\'' +
                ", tenCha='" + tenCha + '\'' +
                ", tenMe='" + tenMe + '\'' +
                ", chucVu='" + chucVu + '\'' +
                ", idThoiKy='" + idThoiKy + '\'' +
                ", description='" + description + '\'' +
                ", urlImage='" + image + '\'' +
                ", urlPath='" + urlPath + '\'' +
                '}';
    }
}
