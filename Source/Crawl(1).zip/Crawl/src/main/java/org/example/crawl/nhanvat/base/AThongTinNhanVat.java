package org.example.crawl.nhanvat.base;

import org.example.model.NhanVat;

import java.io.IOException;

public abstract class AThongTinNhanVat {
    public  abstract NhanVat layThongTinNhanVat(String tenNhanVat);
}
