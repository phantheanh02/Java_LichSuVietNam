package org.example.crawl.nhanvat.wikipedia;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.example.crawl.nhanvat.base.AThongTinNhanVat;
import org.example.crawl.nhanvat.nguoikesu.constant.Regex;
import org.example.model.NhanVat;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.example.util.TienIch.layDuongDanWikiApiTuTenNV;

public class ThongTinNhanVat extends AThongTinNhanVat {

    private String jsonData;
    private String tenNhanVat;
    private String contentData;
    /**
     * lấy thông tin nhân vật
     * @param tenNhanVat
     * @return
     */
    @Override
    public NhanVat layThongTinNhanVat(String tenNhanVat) {
        this.tenNhanVat = tenNhanVat;
        // Lấy Json Data để thực hiện các bước lấy thông tin bên dưới
        layJsonData();
        getContent();
        // Lấy các thông tin cần thiết
        NhanVat nhanVat = new NhanVat();
        if(contentData == null || contentData.isEmpty()) {
            return nhanVat;
        }
        String namSinh;
        String namMat;
        String tenCha;
        String tenMe;
        String image;
        String description;

        namSinh = layNamSinhMat("sinh");
        namMat = layNamSinhMat("mất");
        tenCha = layTenCha();
        tenMe = layTenMe();
        image = layHinhAnh();
        description = layMoTa();

        // Tạo đối tượng nhân vật và set thông tin
        nhanVat.setNamSinh(namSinh);
        nhanVat.setNamMat(namMat);
        nhanVat.setTenCha(tenCha);
        nhanVat.setTenMe(tenMe);
        nhanVat.setImage(image);
        nhanVat.setDescription(description);
        return nhanVat;
    }

    private void layJsonData() {
        String urlString = layDuongDanWikiApiTuTenNV(tenNhanVat);
        // Tạo request
        Request request = new Request.Builder()
                .url(urlString)
                .get()
                .build();
        // Lấy dữ liệu
        OkHttpClient client = new OkHttpClient();
        try {
            Response response = client.newCall(request).execute();
            if (!response.isSuccessful()) {
                // handle error
                throw new IOException("Không thể lấy dữ liệu từ wiki.Http response code: " + response);
            }
            jsonData = response.body().string();
        } catch(IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Lấy nội dung phần content trong wikiAPI
     * @param
     * @return
     */
    public void getContent() {
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode contentNode = null;
        try {
            contentNode = objectMapper.readTree(jsonData)
                    .path("query").path("pages").get(0).path("revisions").get(0).path("slots").path("main").path("content");
            contentData = contentNode.asText();
        } catch (JsonProcessingException e) {
            System.out.println("Không thể lấy content field từ Wiki");
            e.printStackTrace();
        } catch (NullPointerException e) {
            e.printStackTrace();
        }
    }

    /**
     * Lấy năm sinh năm mất
     * @param type
     * @return
     */
    public String layNamSinhMat(String type) {
        String result = null;
        Pattern pattern;
        Matcher matcher;
        if(type.compareToIgnoreCase("sinh") == 0){
            pattern = Pattern.compile(Regex.regexNamSinh);
            matcher = pattern.matcher(contentData);
            if (matcher.find()) {
                result = matcher.group(1);
            }

            else {
                result = layNamSinhDes();
            }
        }
        else if(type.compareToIgnoreCase("mất") == 0){
            pattern = Pattern.compile(Regex.regexNamMat);
            matcher = pattern.matcher(contentData);
            if (matcher.find()) {
                result = matcher.group(1);
            }
            else {
                result = layNamMatDes();
            }
        }
        return result;
    }

    /**
     *  Lấy thông tin năm sinh từ description
     * @return
     */
    public String layNamSinhDes(){
        String result = null;
        Pattern pattern;
        Matcher matcher;
        pattern = Pattern.compile(Regex.regexSinhDes1);
        matcher = pattern.matcher(layMoTa());
        if (matcher.find()) {
            result = matcher.group(1);
            Pattern pattern1 = Pattern.compile(Regex.regexRemove);
            Matcher matcher1 = pattern1.matcher(result);
            if (matcher1.find()) {
                result = result.replace(matcher1.group(1), "");
            }
        }
        else {
            pattern = Pattern.compile(Regex.regexSinhDes2);
            matcher = pattern.matcher(layMoTa());
            if (matcher.find()) {
                result = matcher.group(1);
            }
        }
        return result;
    }

    /**
     * Lấy thông tin năm mất từ description
     * @return
     */
    public  String layNamMatDes(){
        String result = null;
        Pattern pattern;
        Matcher matcher;
        pattern = Pattern.compile(Regex.regexMatDes);
        matcher = pattern.matcher(layMoTa());
        if (matcher.find()) {
            result = matcher.group(1);
        }
        return result;
    }

    /**
     * Lấy tên cha
     * @return
     */
    public String layTenCha() {
        String tenCha = null;
        Pattern pattern1 = Pattern.compile(Regex.regexChaWiki);
        Matcher matcher1 = pattern1.matcher(contentData);
        if (matcher1.find()) {
            tenCha = matcher1.group(1).trim();
        }
        return tenCha;
    }


    /**
     * Lấy tên Mẹ
     * @return
     */
    public String layTenMe() {
        String tenMe = null;
        Pattern pattern = Pattern.compile(Regex.regexMeWiki);
        Matcher matcher = pattern.matcher(contentData);
        if (matcher.find()) {
            tenMe = matcher.group(1).trim();
        }
        return tenMe;
    }

    /**
     * Lấy link ảnh nhân vật
     * @return
     */
    public String layHinhAnh() {
        String img;
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode sourceNode;
        try {
            sourceNode = objectMapper.readTree(jsonData)
                    .path("query").path("pages").get(0).path("thumbnail").path("source");
            img = sourceNode.asText();
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }

        return img;
    }

    /**
     * lấy phần description (mô tả) của nhân vật
     * @return
     */
    public String layMoTa(){
        String extract;
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode extractNode;
        try {
            extractNode = objectMapper.readTree(jsonData)
                    .path("query").path("pages").get(0).path("extract");
            extract = extractNode.asText();
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        return extract;
    }
}
