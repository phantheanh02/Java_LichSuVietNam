package org.example.gui.controllers;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import org.example.gui.constants.LabelDisplay;
import org.example.model.DiTich;
import org.example.model.NhanVat;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.example.model.ThoiKy;
import org.example.util.TienIch;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class DiTichController{
    @FXML
    private TableColumn<DiTich, String> colDiaDiem;

    @FXML
    private TableColumn<DiTich, Integer> colID;

    @FXML
    private TableColumn<DiTich, String> colTen;

    @FXML
    private ImageView imageView;

    @FXML
    private TextField searchTextField;

    @FXML
    private TableView<DiTich> tblData;

    @FXML
    private VBox vBoxInfo;

    FilteredList<DiTich> filteredList;

    public DiTichController() {
        super();
        JavaType type = new ObjectMapper().getTypeFactory().constructCollectionType(ArrayList.class, DiTich.class);
        var data = TienIch.<ArrayList<DiTich>>loadJson(type, "output/di_tich.json");
        ObservableList<DiTich> listNV = FXCollections.observableArrayList(data);
        this.filteredList = new FilteredList<DiTich>(listNV);
    }
    @FXML
    private void initialize() {
        vBoxInfo.setSpacing(5);
        colID.setCellValueFactory(
                new PropertyValueFactory<DiTich, Integer>("id")
        );

        colDiaDiem.setCellValueFactory(
                new PropertyValueFactory<DiTich, String>("diaDiem")
        );

        colTen.setCellValueFactory(
                new PropertyValueFactory<DiTich, String>("ten")
        );

        tblData.setItems(filteredList);
        searchTextField.textProperty().addListener(
                new ChangeListener<String>() {
                    @Override
                    public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                        showFilter(newValue);
                    }
                }
        );

    }

    @FXML
    void clickItem(MouseEvent event) {
        if(event.getClickCount() > 1) {
            DiTich selected = tblData.getSelectionModel().getSelectedItem();
            vBoxInfo.getChildren().clear();
            String imageUrl = "https://i.pinimg.com/originals/ff/a0/9a/ffa09aec412db3f54deadf1b3781de2a.png";
            if(selected.getHinhAnh() != null && selected.getHinhAnh().length() > 0) {
                imageUrl = selected.getHinhAnh();
            }

            String finalImageUrl = imageUrl;
            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    Text text;

                    try {
                        PropertyDescriptor[] lists =  Introspector.getBeanInfo(DiTich.class).getPropertyDescriptors();
                        Collections.reverse(Arrays.asList(lists));
                        Field[] declaredFields = DiTich.class.getDeclaredFields();
                        for(Field declaredField : declaredFields) {
                            Object value = new PropertyDescriptor(declaredField.getName(), DiTich.class).getReadMethod().invoke(selected);
                            if(value != null && !LabelDisplay.notDisplay.contains(declaredField.getName())) {
                                // Nếu trường đó dạng danh sách
                                if(value instanceof ArrayList) {
                                    ArrayList valueArray = (ArrayList) value;
                                    if(valueArray.size() < 1) {
                                        continue;
                                    }
                                    ArrayList duLieu;
                                    if(valueArray.get(0) instanceof Integer) {
                                        duLieu = new ArrayList<ThoiKy>();
                                        if(declaredField.getName() == "idThoiKy") {
                                            for(Object thoiKyObject: valueArray) {
                                                int trieuDaiID = (int) thoiKyObject;
                                                ThoiKy thoiKy = ThoiKy.getByID(trieuDaiID);
                                                if(thoiKy != null)
                                                    duLieu.add(thoiKy);
                                            }
                                        }

                                        if(duLieu.size() < 1) {
                                            continue;
                                        }
                                    } else {
                                        duLieu = valueArray;
                                    }

                                    Class elementType = duLieu.get(0).getClass();
                                    Field[] subFields = elementType.getDeclaredFields();
                                    TreeItem<String> rootItem = new TreeItem<>(LabelDisplay.labelDisPlay.get(declaredField.getName()));
                                    rootItem.setExpanded(true);
                                    TreeItem<String> subRootItem;
                                    for(Object temp: duLieu) {
                                        subRootItem = new TreeItem<>();
                                        subRootItem.setExpanded(true);
                                        for(Field subField: subFields) {
                                            Object subValue = new PropertyDescriptor(subField.getName(), elementType).getReadMethod().invoke(temp);
                                            if(subValue == null)
                                                continue;
                                            subRootItem.getChildren().add(new TreeItem<String>(LabelDisplay.labelDisPlay.get(subField.getName()) + ": " +subValue.toString()));
                                        }

                                        rootItem.getChildren().add(subRootItem);
                                    }

                                    TreeView<String> tree = new TreeView<String>(rootItem);
                                    AnchorPane anchorPane = new AnchorPane(tree);
                                    anchorPane.setPrefSize(150, 150);
                                    tree.setPrefSize(600, 150);
                                    vBoxInfo.getChildren().add(anchorPane);
                                    System.out.println(tree.toString());


                                    // Nếu trường đó dạng String
                                } else if(value instanceof String) {
                                    if(((String) value).length() > 0) {
                                        text = new Text(LabelDisplay.labelDisPlay.get(declaredField.getName()) + ": " + value.toString());
                                        text.setStyle("-fx-font: 15 arial;");
                                        text.setLineSpacing(5);
                                        text.wrappingWidthProperty().bind(vBoxInfo.widthProperty());
                                        vBoxInfo.getChildren().addAll(text);
                                    }

                                }

                            }
                        }
                    } catch (IntrospectionException e) {
                        e.printStackTrace();
                    } catch (InvocationTargetException e) {
                        e.printStackTrace();
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    }
                }
            });
            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    // Render thông tin
                    // Render ảnh
                    Image image = new Image(finalImageUrl);
                    if (image.isError()) {
                        System.out.println("Error loading image from ");

                    } else {
                        System.out.println("Successfully loaded image from ");
                    }
                    imageView.setImage(image);
                }
            });

        }
    }

    void showFilter(String filter) {
        filteredList.setPredicate(item -> {
            if(filter.isEmpty()) {
                return true;
            }
            try {
                String keyword = filter.toLowerCase();
                return item.getTen().toLowerCase().contains(keyword);

            } catch(Exception e) {
                e.printStackTrace();
            }

            return true;

        });

    }


}
