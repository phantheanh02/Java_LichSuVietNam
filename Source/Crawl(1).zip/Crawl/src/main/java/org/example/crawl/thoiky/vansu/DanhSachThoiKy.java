package org.example.crawl.thoiky.vansu;

import org.example.crawl.thoiky.base.ADanhSachThoiKy;
import org.example.model.ThoiKy;
import org.example.model.UniqueID;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class DanhSachThoiKy extends ADanhSachThoiKy {
    private Document htmlPages;
    private String thoiKyOutput = "output/thoiky.json";
    private ArrayList<ThoiKy> listThoiKy;
    private ArrayList<String> listTen;
    private ArrayList<String> listMoTa;
    private ArrayList<ArrayList<String>> listThoiDiemBatDau;


    public DanhSachThoiKy() {
        layHTML();
    }

    @Override
    public ArrayList<ThoiKy> layDanhSachThoiKy() {
        listThoiKy = new ArrayList<>();
        listMoTa = layMoTa();
        listTen = layTenTrieuDai();
        listThoiDiemBatDau = layThoiDiem();
        for(int i = 0; i < listTen.size(); i++) {
            ThoiKy temp = new ThoiKy();
            temp.setIdThoiKy(UniqueID.getIdThoiKy());
            temp.setTenThoiKy(listTen.get(i));
            temp.setMoTa(listMoTa.get(i));
            temp.setThoiGianBatDau(listThoiDiemBatDau.get(i).get(0));
            temp.setThoiGianKetThuc(listThoiDiemBatDau.get(i).get(1));
            listThoiKy.add(temp);
        }
        return listThoiKy;
    }

    public ArrayList<ArrayList<String>> layThoiDiem() {
        ArrayList<ArrayList<String>> result = new ArrayList<>();
        Elements listTitle = htmlPages.select("body > div.ui.container > div > b > a:nth-child(1)");

        for(Element temp: listTitle) {
            String titleText = temp.text().trim();
            ArrayList<String> thoiDiem = new ArrayList<>();
            if(titleText.contains("(")) {
                titleText = titleText.substring(titleText.indexOf("(") + 1, titleText.indexOf(")"));
                if(titleText.contains("-")) {
                    Collections.addAll(thoiDiem, titleText.split("-"));
                } else if(titleText.contains("–")) {
                    Collections.addAll(thoiDiem, titleText.split("–"));
                } else {
                    thoiDiem.add(null);
                    thoiDiem.add(null);
                }

            } else {
                thoiDiem.add(null);
                thoiDiem.add(null);
            }

            result.add(thoiDiem);
        }

        return result;

    }

    public ArrayList<String> layTenTrieuDai() {
        ArrayList<String> result = new ArrayList<>();
        Elements listTitle = htmlPages.select("body > div.ui.container > div > b > a:nth-child(1)");

        for(Element temp: listTitle) {
            String titleText = temp.text();
            if(titleText.contains("(")) {
                titleText = titleText.substring(0, titleText.indexOf("("));
            }

            result.add(titleText.trim());
        }

        return result;

    }



    public ArrayList<String> layMoTa() {
        String regex = "<div>\n"
                + ".*?\n"
                + "<\\/div>";
        Elements listElements = htmlPages.select(".ui.container:nth-child(2n)");
        String htmlString = listElements.html().trim();
        htmlString = htmlString.replaceAll(regex, " ");
        htmlString = htmlString.replaceAll("<h3 .*?>.*?<\\/h3>", "");
        htmlString = htmlString.replace("<p></p>", "").trim();
        ArrayList<String> temp = new ArrayList<String>(Arrays.asList( htmlString.split("\n")));
        ArrayList<String> result = new ArrayList<>();
        for(int i = 0; i < temp.size(); i++) {
            if(temp.get(i).isEmpty() || temp.get(i) == null)
                continue;
            result.add(temp.get(i).trim());
        }
        return result;
    }

    public void layHTML() {
        try {
            htmlPages = Jsoup.connect("https://vansu.vn/viet-nam/nien-bieu-lich-su").get();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
