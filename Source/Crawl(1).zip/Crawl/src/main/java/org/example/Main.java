package org.example;
import org.example.controller.DiTichController;
import org.example.controller.LeHoiController;
import org.example.controller.NhanVatController;
import org.example.crawl.sukien.LuuDuLieuSuKien;
import org.example.crawl.thoiky.LuuDuLieuThoiKy;
import org.example.model.DiTich;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        menu();
    }

    public static void menu() {
        System.out.println("Danh sách tính năng của chương trình");
        System.out.println("1. Lấy dữ liệu thời kì");
        System.out.println("2. Lấy dữ liệu nhân vật");
        System.out.println("3. Lấy dữ liệu lễ hội");
        System.out.println("4. Lấy dữ liệu di tích");
        System.out.println("5. Lấy dữ liệu sự kiện");
        System.out.println("0. Thoát chương trình");
        System.out.print("Lựa chọn của bạn: ");
        Scanner sc = new Scanner(System.in);
        int value = sc.nextInt();
        luaChon(value);
    }

    public static void luaChon(int value) {
        int code = -1;
        switch (value) {
            case 1:
                LuuDuLieuThoiKy luuDuLieuThoiKy = new LuuDuLieuThoiKy();
                luuDuLieuThoiKy.start();
                break;
            case 2:
                NhanVatController nhanVatController = new NhanVatController();
                code = nhanVatController.start();
                break;
            case 3:
                LeHoiController leHoiController = new LeHoiController();
                leHoiController.start();
                break;
            case 4:
                DiTichController diTichController = new DiTichController();
                diTichController.start();
                break;
            case 5:
                LuuDuLieuSuKien luuDuLieuSuKien = new LuuDuLieuSuKien(0);
                luuDuLieuSuKien.start();
            break;
            default:
                throw new RuntimeException("Lựa chọn không hợp lệ");

        }

    }
}
