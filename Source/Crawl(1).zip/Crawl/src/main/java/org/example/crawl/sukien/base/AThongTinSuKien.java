package org.example.crawl.sukien.base;

import org.example.model.SuKien;

public abstract class AThongTinSuKien {
    public abstract SuKien layThongTinSuKien(String source);
}