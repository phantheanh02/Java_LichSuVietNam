package org.example.crawl.nhanvat;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.controller.StateController;
import org.example.crawl.nhanvat.nguoikesu.DanhSachTenNhanVat;
import org.example.crawl.nhanvat.nguoikesu.ThongTinNhanVat;
import org.example.model.NhanVat;
import org.example.model.StateCrawl;
import org.example.util.TienIch;

import java.io.File;
import java.util.ArrayList;

public class LuuDuLieuNV {
    ArrayList<NhanVat> listNV = new ArrayList<>();
    private String nvFilePath = "output/nhan_vat.json";
    private int mode = 0;
    private StateController stateController;
    private StateCrawl currentState;

    public LuuDuLieuNV(int mode) {
        this.mode = mode;
        this.stateController = new StateController();
        // Nếu cào lại từ đầu
        if(mode == 0) {
            stateController.restartState();
        }

        if(!TienIch.checkFileExist(nvFilePath) || mode == 0) {
            DanhSachTenNhanVat dsNhanVat = new DanhSachTenNhanVat();
            dsNhanVat.layDanhSachTenNhanVat();
            dsNhanVat.luuDanhSachNhanVat();
        }
        currentState = stateController.loadProgress();
    }

    public void start() {
        ThongTinNhanVat nguoikesu = new ThongTinNhanVat();
        // Kiểm tra danh sách nhân vật tồn tại không
        loadDanhSachNhanVat();

        int lastProgressIndex = currentState.getLastProcessNVIndex();
        org.example.crawl.nhanvat.wikipedia.ThongTinNhanVat wikipedia = new org.example.crawl.nhanvat.wikipedia.ThongTinNhanVat();
        org.example.crawl.nhanvat.vansu.ThongTinNhanVat vansu = new org.example.crawl.nhanvat.vansu.ThongTinNhanVat();
        System.out.printf("Còn tất cả %d nhân vật cần xử lý\n", (listNV.size() - lastProgressIndex));
        for(int i = lastProgressIndex; i < listNV.size(); i++) {
            if(!(listNV.get(i) instanceof NhanVat)) {
                continue;
            }
            NhanVat temp = (NhanVat)listNV.get(i);
            if(temp.getTenNhanVat() == null)
                continue;
            System.out.printf("Xử lý nhân vật có ID: %d\n", temp.getIdNhanVat());
            NhanVat nv1 = nguoikesu.layThongTinNhanVat(temp.getTenNhanVat());
            NhanVat nv2 = wikipedia.layThongTinNhanVat(temp.getTenNhanVat());
            NhanVat nv3 = vansu.layThongTinNhanVat(temp.getTenNhanVat());
            NhanVat result = gopThongTin(nv1, nv2);
            result.setIdNhanVat(temp.getIdNhanVat());
            if(nv3.getIdThoiKy() != null && nv3.getIdThoiKy().size() > 0) {
                result.setIdThoiKy(nv3.getIdThoiKy());
            }
            listNV.set(i, result);
            // Lưu dữ liệu
            TienIch.luuJson(nvFilePath, listNV);
            currentState.setLastProcessNVIndex(i);
            stateController.saveProgress(currentState);

            System.out.printf("\tHoàn tất xử lý nhân vật có ID: %d\n", temp.getIdNhanVat());
            System.out.println("===================================");
        }

    }

    public NhanVat gopThongTin(NhanVat nv1, NhanVat nv2) {
        NhanVat result = TienIch.gopObject(nv1, nv2);
        if(result == null) {
            return nv1;
        }
        return result;
    }


    public void loadDanhSachNhanVat() {
        File f = new File(nvFilePath);
        if(!f.exists() || f.isDirectory()) {
            System.out.println("File lưu danh sách nhân vật không tồn tại");
            return ;
        }

        JavaType type = new ObjectMapper().getTypeFactory().constructCollectionType(ArrayList.class, NhanVat.class);
        var data = TienIch.<ArrayList<NhanVat>>loadJson(type, nvFilePath);
        if(data != null) {
            listNV = data;
        } else {
            throw new RuntimeException("Không thể parse file danh sách nhân vật");
        }
    }
}
