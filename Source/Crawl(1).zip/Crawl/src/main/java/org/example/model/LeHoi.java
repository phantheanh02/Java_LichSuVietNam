package org.example.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor

public class LeHoi {
    private int id;
    private String ten;
    private String diaDiem;
    private String thoiGian;
    private String moTa;
}
