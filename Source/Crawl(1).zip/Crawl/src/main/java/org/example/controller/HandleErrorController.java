package org.example.controller;

public class HandleErrorController {

    public class ErrorInfo {

    }
}
