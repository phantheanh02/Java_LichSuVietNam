package org.example.crawl.ditich.base;

import org.example.model.DiTich;

import java.util.ArrayList;

public abstract class ADanhSachDiTich {
    public  abstract ArrayList<DiTich> layDanhSachDiTich();
}
