package org.example.util;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.text.Normalizer;
import java.util.regex.Pattern;

public class TienIch {
    public static String layDuongDanTuTenNV(String tenNhanVat) {
        tenNhanVat = tenNhanVat.toLowerCase();
        String nfdNormalizedString = Normalizer.normalize(tenNhanVat, Normalizer.Form.NFD);
        Pattern pattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
        tenNhanVat =  pattern.matcher(nfdNormalizedString).replaceAll("");
        tenNhanVat = tenNhanVat.replaceAll(" ", "-");
        return VNCharacterUtils.removeAccent(tenNhanVat);
    }

    public static String layDuongDanWikiApiTuTenNV(String tenNhanVat) {
        tenNhanVat = "https://vi.wikipedia.org/w/api.php?action=query&prop=revisions|pageimages|extracts&titles=" + tenNhanVat.replace(' ','_') + "&rvslots=*&rvprop=content&formatversion=2&format=json&rvsection=0&pithumbsize=200&explaintext=&exintro";
        return tenNhanVat;
    }
    public static String layDuongDanWikiApiTuTenDoiTuong(String tenLeHoi) {
        tenLeHoi = "https://vi.wikipedia.org/w/api.php?action=query&prop=revisions|pageimages|extracts&titles=" +tenLeHoi + "&rvslots=*&rvprop=content&formatversion=2&format=json&rvsection=0&pithumbsize=200&explaintext=&exintro";
        return tenLeHoi;
    }

    public static Document layHTML(String url) {
        try {
            return Jsoup.connect(url).get();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    public static void luuJson(String filePath, Object data) {
        try {
            new ObjectMapper().writerWithDefaultPrettyPrinter().writeValue(new File(filePath), data);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static boolean checkFileExist(String filePath) {
        File f = new File(filePath);
        if(!f.exists() || f.isDirectory()) {
            return false;
        }
        return true;
    }
    public static boolean taoFile(String filePath) {
        File f = new File(filePath);
        try {
            f.createNewFile();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static <T extends Object> T loadJson(JavaType type, String filePath) {
        File f = new File(filePath);
        if(!f.exists() || f.isDirectory()) {
            System.out.printf("File %s không tồn tại\n", filePath);
            return null;
        }

        try {
            var data = new ObjectMapper().readValue(f, type);
            if(data != null) {
                T result = (T)data;
                return result;
            }
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static <T> T gopObject(T first, T second){
        Class<?> clas = first.getClass();
        Field[] fields = clas.getDeclaredFields();
        Object result = null;
        try {
            result = clas.getDeclaredConstructor().newInstance();
            for (Field field : fields) {
                field.setAccessible(true);
                Object value1 = field.get(first);
                Object value2 = field.get(second);
                Object value = (value1 != null) ? value1 : value2;
                field.set(result, value);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return (T) result;
    }

    public static String loadJsonTuUrl(String url) {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .build();
        Response response = null;
        try {
            response = client.newCall(request).execute();
            return response.body().string();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }
}
