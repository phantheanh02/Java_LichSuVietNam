package org.example.crawl.nhanvat.nguoikesu;

import org.example.crawl.nhanvat.nguoikesu.constant.Regex;
import org.example.crawl.nhanvat.nguoikesu.constant.Regex.*;
import org.example.crawl.nhanvat.base.AThongTinNhanVat;
import org.example.model.ChucVu;
import org.example.model.NhanVat;
import org.example.util.TienIch;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ThongTinNhanVat extends AThongTinNhanVat {

    private Document htmlPage;
    private String tenNhanVat;

    /**
     * lấy thông tin nhân vật
     * @param tenNhanVat
     * @return
     */
    @Override
    public NhanVat layThongTinNhanVat(String tenNhanVat) {
        this.tenNhanVat = tenNhanVat;
        // Lấy HTML để thực hiện các bước lấy thông tin bên dưới
        layHTML();
        // Lấy các thông tin cần thiết.
        String tenCha = null;
        String tenMe = null;
        tenCha = layTenCha();
        tenMe = layTenMe();
        // Tạo đối tượng nhân vật và set thông tin
        NhanVat nhanVat = new NhanVat();
        nhanVat.setTenCha(tenCha);
        nhanVat.setTenNhanVat(tenNhanVat);
        nhanVat.setTenMe(tenMe);
        nhanVat.setNamSinh(layThongSinhMat("Sinh"));
        nhanVat.setNamMat(layThongSinhMat("Mất"));
        nhanVat.setChucVu(layChucVu());
        nhanVat.setUrlPath("https://nguoikesu.com/nhan-vat/" +TienIch.layDuongDanTuTenNV(tenNhanVat));
        return nhanVat;
    }


    /**
     * Lấy toàn bộ HTMLM để phục vụ cho việc bóc tách dữ liệu
     */
    public void layHTML() {
        try {
            htmlPage = Jsoup.connect("https://nguoikesu.com/nhan-vat/" + TienIch.layDuongDanTuTenNV(tenNhanVat)).get();
        } catch (IOException e) {
            System.out.println("Request Time Out");
            //throw new RuntimeException(e);
        }
    }

    /**
     * Lấy thông tin năm sinh/mất, địa điểm sinh/mất
     * @return String
     */
    public String layThongSinhMat(String type) {
        String info= null;
        Elements element = htmlPage.select("#content > div.com-content-article.item-page.page-list-items > div.com-content-article__body > div.infobox > table > tbody > tr");
        for (Element tmp:element) {
            String check = tmp.select("> th ").text();
            if (check.compareToIgnoreCase(type) == 0)
                info = tmp.select("> td").text();
        }
        if (info == null) return info; // Không tìm thấy
        return  info;
    }

    /**
     * Lấy thông tin chức vụ của nhân vật
     * @return
     */
    public ArrayList<ChucVu> layChucVu() {
        ArrayList<ChucVu> chucVus = new ArrayList<>();
        ChucVu chucVuNhanVat = new ChucVu();

        String checkThongTinChucVu = null;
        String tenChucVu = null;
        boolean luuThongTin = false;

        Elements element = htmlPage.select("#content > div.com-content-article.item-page.page-list-items > div.com-content-article__body > div.infobox > table > tbody > tr");
        for (Element tmp:element) {
            // Lưu thông tin chức vụ
            Element checkChucVu = tmp.select("> th:only-child, div:only-child").first();
            if (checkChucVu != null ) {
                tenChucVu = checkChucVu.text();
                if (luuThongTin) {
                    chucVus.add(chucVuNhanVat);
                    chucVuNhanVat = new ChucVu();
                    luuThongTin = false;
                }
            }

            // Lấy thông tin chức vụ
            checkThongTinChucVu = tmp.select("> th ").text();

            if (checkThongTinChucVu.contains("Tại vị")) {
                checkThongTinChucVu = tmp.select("> td ").text();
                chucVuNhanVat.setTaiVi(checkThongTinChucVu);
                luuThongTin = true;
            }
            else if (checkThongTinChucVu.contains("Tiền nhiệm")) {
                checkThongTinChucVu = tmp.select("> td ").text();
                chucVuNhanVat.setTen(tenChucVu);
                chucVuNhanVat.setTienNhiem(checkThongTinChucVu);
                luuThongTin = true;
            }
            else if (checkThongTinChucVu.contains("Kế nhiệm")) {
                checkThongTinChucVu = tmp.select("> td ").text();
                chucVuNhanVat.setKeNhiem(checkThongTinChucVu);
                chucVuNhanVat.setTen(tenChucVu);
                luuThongTin = true;
            }
            else if (checkThongTinChucVu.contains("Nhiệm kỳ")) {
                chucVuNhanVat.setTen(tenChucVu);
                checkThongTinChucVu = tmp.select("> td ").text();
                chucVuNhanVat.setNhiemKy(checkThongTinChucVu);
                luuThongTin = true;
            }
        }

        return chucVus;
    }

    /**
     * Lấy tên cha
     *
     */
    public String layTenCha() {
        String tenCha = null;
        Elements thongTinCha = htmlPage.select("#content > div.com-content-article.item-page.page-list-items > div.com-content-article__body > div.infobox > table > tbody > tr");
        for(Element tmp : thongTinCha)
        {
            // thẻ th chứa tiêu đề, thẻ td chứa nôj dung
            Elements thongTinTd = tmp.select("> td ");
            Element thuocTinhNhanVat = tmp.select("> th").first();
            if(thuocTinhNhanVat == null) continue;
            if(thuocTinhNhanVat.text().compareToIgnoreCase("thân phụ") == 0)
                tenCha = thongTinTd.text();
            else{
                tenCha = layThongTinCha(String.valueOf(htmlPage));
            }
        }
        return tenCha;
    }

    /**
     * select vào toàn bộ thẻ p của page để lấy thông tin của cha
     * @param url
     * @return
     * @throws IOException
     */
    public String layThongTinCha(String url) {
        String tenCha = null;
        Elements layThongTinTuTheP = htmlPage.select("#content > div.com-content-article.item-page.page-list-items > div.com-content-article__body p");
        for (Element tmp : layThongTinTuTheP) {
            tenCha = layThongTinChaP(tmp.text());
        }
        return tenCha;
    }

    /**
     * Lấy thông tin cha từ thẻ P của page bằng regex
     * @param text
     * @return
     */
    public static String layThongTinChaP(String text) {
        String father = null;
        Pattern pattern1 = Pattern.compile(Regex.regexCha1);
        Matcher matcher1 = pattern1.matcher(text);
        if (matcher1.find()) {
            father = matcher1.group(1);
        }
        return father;
    }

    /**
     * Lấy tên Mẹ
     *
     */
    public String layTenMe() {
        String tenMe = null;
        Elements thongTinMe = htmlPage.select("#content > div.com-content-article.item-page.page-list-items > div.com-content-article__body > div.infobox > table > tbody > tr");
        for(Element tmp : thongTinMe)
        {
            // thẻ th chứa tiêu đề, thẻ td chứa nôj dung
            Elements thongTinTd = tmp.select("> td ");
            Element thuocTinhNhanVat = tmp.select("> th").first();
            if(thuocTinhNhanVat == null) continue;
            if(thuocTinhNhanVat.text().compareToIgnoreCase("thân mẫu") == 0)
                tenMe = thongTinTd.text();
            else{
                tenMe = layThongTinMe(String.valueOf(htmlPage));
            }
        }

        return tenMe;
        //câu lệnh regular expression tìm cha mẹ trên API wiki: /cha(.*?)=(.*?)\\n/gm
        // Trong trường hợp các thẻ table trống thông tin cha và mẹ thì cần select vào toàn bộ thẻ <p> của trang web để tìm
    }

    /**
     * select vào toàn bộ thẻ p của page để lấy thông tin của mẹ
     * @param url
     * @return
     * @throws IOException
     */
    public String layThongTinMe(String url) {
        String tenMe = null;
        Elements layThongTinTuTheP = htmlPage.select("#content > div.com-content-article.item-page.page-list-items > div.com-content-article__body p");
        for (Element tmp : layThongTinTuTheP) {
            tenMe = layThongTinMeP(tmp.text());
        }
        return tenMe;
    }

    /**
     * Lấy thông tin Mẹ từ thẻ P của page bằng regex
     * @param text
     * @return
     * @throws IOException
     */
    public static String layThongTinMeP(String text) {
        String father = null;
        // t để hai trường hợp duyệt tìm từ khóa "Cha" và "cha" nhằm so sánh kết quả và khả năng khớp (từ khóa "Cha" đưa ra thông tin chính xác hơn so với "cha")
        Pattern pattern1 = Pattern.compile(Regex.regexMe1);
        Matcher matcher1 = pattern1.matcher(text);
        Pattern pattern2 = Pattern.compile(Regex.regexMe2);
        Matcher matcher2 = pattern2.matcher(text);
        if (matcher1.find()) {
            father = matcher1.group(1);
            return father;
        }
        if (matcher2.find()) {
            father = matcher2.group(1);
            return father;
        }
        return father;
    }
}
