package org.example.crawl.nhanvat.base;

import org.example.model.NhanVat;

import java.util.ArrayList;

public abstract class ADanhSachTenNhanVat {
    abstract public ArrayList<NhanVat> layDanhSachTenNhanVat();
}
