package org.example.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SuKien {
    private int idSuKien;
    private String tenSuKien;
    private String moTa;
    private String thoiDiemBatDau;
    private String thoiDiemKetThuc;
    private ArrayList<Integer> nhanVatLienQuan;

    private String image;
    private String urlPath;

    @Override
    public String toString() {
        return "SuKien{" +
                "idSuKien=" + idSuKien +
                ", tenSuKien='" + tenSuKien + '\'' +
                ", moTa='" + moTa + '\'' +
                ", thoiDiemBatDau='" + thoiDiemBatDau + '\'' +
                ", thoiDiemKetThuc='" + thoiDiemKetThuc + '\'' +
                ", nhanVatLienQuan=" + nhanVatLienQuan +
                ", image='" + image + '\'' +
                ", urlPath='" + urlPath + '\'' +
                '}';
    }
}