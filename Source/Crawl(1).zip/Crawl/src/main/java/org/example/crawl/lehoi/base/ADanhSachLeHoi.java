package org.example.crawl.lehoi.base;

import org.example.model.LeHoi;

import java.util.ArrayList;

public abstract class ADanhSachLeHoi {
    public abstract ArrayList<LeHoi> danhSachLeHoi();

}
