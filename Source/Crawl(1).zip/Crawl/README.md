# Giải thích project
## 1. Package nhanvat.base
- Các class để cào dữ liệu từ các nguồn khác nhau cần kế thừa abstract class <b>ADanhSachTenNhanVat</b> và <b>AThongTinNhanVat</b>
- Chẳng hạn như ở nguồn nguoikesu.com, class <b>DanhSachTenNhanVat</b> kế thừa <b>ADanhSachTenNhanVat</b>
- Điều này nhằm tạo tính thống nhất trong trường hợp có nhiều nguồn lấy dữ liệu
## 2. Package util
- Chứa các hàm tiện ích
- Chẳng hạn như function layDuongDanTuTenNV sẽ chuyển tên nhân vật sang dạng path
- Ví dụ: Hồ Chính Minh sẽ chuyển thành ho-chi-minh
- Tại sao cần làm vậy thì hãy nhìn vào URL: https://nguoikesu.com/nhan-vat/duong-van-minh

# Quy tắc
- Sử dụng tiếng Việt khi đặt tên biến, hàm, class
- <b>Sau</b> khi viết xong function thì gõ <b style="color: red">/**</b> và Enter để tạo comment cho hàm đó
- Tên biến, hàm đặt dạng camel case <img src="https://khalilstemmler.com/img/blog/camel-snake-pascal-case/camel-case-snake-case-pascal-case.png">
- Tên hàm cần có động từ: layNamSinh(lấy năm sinh), layThongTinNhanVat(lấy thông tin nhân vật)
- Hoàn thành mỗi tính năng cần commit luôn, tránh trường hợp commit nhiều tính năng trong 1 lần
  - Ví dụ: Làm xong hàm lấy năm sinh thì **commit** ngay với **message**: Hoàn thiện hàm lấy năm sinh
