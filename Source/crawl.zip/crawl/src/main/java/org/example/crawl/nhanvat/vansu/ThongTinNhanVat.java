package org.example.crawl.nhanvat.vansu;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.crawl.nhanvat.base.AThongTinNhanVat;
import org.example.model.NhanVat;
import org.example.model.ThoiKy;
import org.example.util.TienIch;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.ArrayList;

public class ThongTinNhanVat extends AThongTinNhanVat {
    private Document htmlPage;
    private String tenNhanVat;
    private String tenKhac;
    private ArrayList<ThoiKy> listThoiKy;
    public ThongTinNhanVat() {
        JavaType type = new ObjectMapper().getTypeFactory().constructCollectionType(ArrayList.class, ThoiKy.class);
        listThoiKy = TienIch.loadJson(type, "output/thoiky.json");
    }

    @Override
    public NhanVat layThongTinNhanVat(String tenNhanVat) {
        this.tenNhanVat = tenNhanVat;
        NhanVat nhanVat = new NhanVat();
        htmlPage = TienIch.layHTML("https://vansu.vn/viet-nam/viet-nam-nhan-vat?keyword=" + tenNhanVat);
        Element linkElement = htmlPage.selectFirst("body > div.ui.container > table > tbody > tr > td:nth-child(1) > a:nth-child(1)");
        if(linkElement == null) {
            return nhanVat;
        }

        String nvLink = linkElement.attr("href");
        if(nvLink == null || nvLink.isEmpty()) {
            return nhanVat;
        }
        tenKhac = linkElement.text().trim();
        nhanVat.setIdThoiKy(layThoiKy(nvLink));

        return nhanVat;
    }

    public ArrayList<Integer> layThoiKy(String url) {
        ArrayList<Integer> idThoiKy = new ArrayList<>();
        Document nhanVatHTML = TienIch.layHTML("https://vansu.vn" + url);
        Elements trElement = nhanVatHTML.select("table.table > tbody > tr:not(:last-child)");

        for(Element temp: trElement) {
            String fieldName = temp.selectFirst("td:nth-child(1)").text();
            String fieldValue = temp.selectFirst("td:nth-child(2)").text();
            if(fieldName.toLowerCase().contains("tên khác")) {
                if(!fieldValue.toLowerCase().contains(tenNhanVat.toLowerCase()) && !(tenKhac.compareToIgnoreCase(tenNhanVat) != 0)) {
                    return idThoiKy;
                }
            } else if(fieldName.toLowerCase().contains("thời kì")) {
                for(int i = 0; i < listThoiKy.size(); i++) {
                    ThoiKy thoiKy = listThoiKy.get(i);
                    if(thoiKy.getThoiGianBatDau() == null || thoiKy.getThoiGianKetThuc() == null) {
                        continue;
                    }
                    String thoiGianTonTai = thoiKy.getThoiGianBatDau() + "-" + thoiKy.getThoiGianKetThuc();
                    String tenThoiKy = thoiKy.getTenThoiKy();
                    if(fieldValue.toLowerCase().contains(thoiGianTonTai.toLowerCase()) || fieldValue.toLowerCase().contains(tenThoiKy.toLowerCase())) {
                        idThoiKy.add(thoiKy.getIdThoiKy());
                    }
                }
            }
        }
        return idThoiKy;
    }

    public static void main(String[] args) {
       ThongTinNhanVat thongTinNhanVat = new ThongTinNhanVat();
       System.out.println(thongTinNhanVat.layThongTinNhanVat("Bảo Đại"));
    }

}
