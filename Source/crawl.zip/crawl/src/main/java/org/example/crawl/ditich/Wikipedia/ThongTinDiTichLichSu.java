package org.example.crawl.ditich.Wikipedia;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.example.crawl.ditich.base.AThongTinDiTich;
import org.example.model.DiTich;
import org.example.model.LeHoi;
import org.example.util.TienIch;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;

public class ThongTinDiTichLichSu extends AThongTinDiTich {

    private static String layJsonData;
    private Document htmlPages;
    private String tenDiTich;
    @Override
    public DiTich layThongTinNhanVat(String tenDiTich) {
        this.tenDiTich = tenDiTich;
        layHTML();
        String diaDiem = null;
        String moTa = null;
        ArrayList<String> hinhAnh = new ArrayList<>();

        DiTich diTich = new DiTich();
        diaDiem = layThuocTinhDiTich("Địa điểm");
        tenDiTich = layThuocTinhDiTich("Tên");
        moTa = layThuocTinhDiTich("Mô tả");
        hinhAnh.add(layThuocTinhDiTich("ảnh"));
        diTich.setTen(tenDiTich);
        diTich.setDiaDiem(diaDiem);
        diTich.setMoTa(moTa);
        diTich.setHinhAnh(String.valueOf(hinhAnh));
        return diTich;
    }

    private void layHTML(){
        try {
            htmlPages = Jsoup.connect("https://vi.wikipedia.org/wiki/Di_t%C3%ADch_qu%E1%BB%91c_gia_%C4%91%E1%BA%B7c_bi%E1%BB%87t_(Vi%E1%BB%87t_Nam)").get();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private String layThuocTinhDiTich(String type){
        String thongTinDiTich = null;
        for (int index = 17; index <= 41; index += 2) {
            Elements thongTinDiTichs = htmlPages.select("#mw-content-text > div.mw-parser-output > table:nth-child(" + index + ") > tbody > tr");
            for (Element tmp : thongTinDiTichs) {
                Elements thuocTinhDiTichs = tmp.select(" > td");
                int index1 = 0;
                for(Element thuocTinhLeHoi : thuocTinhDiTichs){
                    if(index1++ > 2) break;
                    if(index1 == 1){
                        Element linkMoTa = thuocTinhLeHoi.selectFirst("> a");
                        String moTa = linkMoTa.attr("href").substring(6);

                        if(type.compareToIgnoreCase("Tên") == 0) thongTinDiTich = thuocTinhLeHoi.text();

                        if(type.compareToIgnoreCase("Mô tả") == 0)  thongTinDiTich = layMoTa(TienIch.layDuongDanWikiApiTuTenDoiTuong(moTa));

                        if(type.compareToIgnoreCase("ảnh") == 0)    thongTinDiTich = layAnh(TienIch.layDuongDanWikiApiTuTenDoiTuong(moTa));
                    }

                    if(type.compareToIgnoreCase("ảnh") == 0 && index1 == 2){
                        Element linkMoTa = thuocTinhLeHoi.selectFirst("> a");
                        thongTinDiTich = linkMoTa.attr("abs:href");
                    }

                    if(type.compareToIgnoreCase("địa điểm") == 0 && index1 == 3) thongTinDiTich = thuocTinhLeHoi.text();
                }
            }
        }
        return thongTinDiTich;
    }

    /**
     * Call API lấy data Json
     * @param url
     * @return
     */
    private static String layJsonData(String url) {
        // Tạo request
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .build();
        Response response = null;
        try {
            response = client.newCall(request).execute();
            return response.body().string();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    private static String layMoTa(String url) {
        String extract = null;
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode extractNode;
        //Trong 1 số trường hợp, 1 vài link lễ hội chưa được cập nhật thông tin trên wiki mà chỉ có trang trắng, hoặc đường dẫn bằng bên bị sai cú pháp (lỗi do web)
        //vì vậy json sẽ không có cấu trúc thông thường của wikiApi. Do đó sẽ xảy ra hiện tượng đường dẫn là null khi truy cập vào các trường, từ đó gây ra lỗi
        try {
            JsonNode rootNode = objectMapper.readTree(layJsonData(url));
            JsonNode pagesNode = rootNode.path("query").path("pages").get(0);
            //Nếu pagesNode khác null thì tiếp tục select và trường "extract"
            if (pagesNode != null) {
                extractNode = pagesNode.path("extract");
                extract = extractNode.asText();
            }
        } catch (JsonProcessingException e) {
            // Log error or do something else
            return null;
        }
        return extract;
    }

    private static String layAnh(String url) {
        String img = null;
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode extractNode;
        //Trong 1 số trường hợp, 1 vài link lễ hội chưa được cập nhật thông tin trên wiki mà chỉ có trang trắng, hoặc đường dẫn bằng bên bị sai cú pháp (lỗi do web)
        //vì vậy json sẽ không có cấu trúc thông thường của wikiApi. Do đó sẽ xảy ra hiện tượng đường dẫn là null khi truy cập vào các trường, từ đó gây ra lỗi
        try {
            JsonNode rootNode = objectMapper.readTree(layJsonData(url));
            JsonNode pagesNode = rootNode.path("query").path("pages").get(0);
            //Nếu pagesNode khác null thì tiếp tục select và trường "extract"
            if (pagesNode != null) {
                extractNode = pagesNode.path("thumbnail").path("source");
                img = extractNode.asText();
            }
        } catch (JsonProcessingException e) {
            // Log error or do something else
            return null;
        }
        return img;
    }


}
