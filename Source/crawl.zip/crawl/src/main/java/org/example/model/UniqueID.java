package org.example.model;

public class UniqueID {
    private static int idNV = 0;
    private static int idDiTich = 0;
    private static int idSuKien = 0;
    private static int idThoiKy = 0;
    private static int idLeHoi = 0;
    
    public static int getIdNV() {
        idNV++;
        return idNV;
    }

    public static int getIdSuKien() {
        idSuKien++;
        return idSuKien;
    }

    public static int getIdDiTich() {
        idDiTich++;
        return idDiTich;
    }

    public static int getIdThoiKy() {
        idThoiKy++;
        return idThoiKy;
    }
    
    public static int getIdLeHoi() {
        idLeHoi++;
        return idLeHoi;
    }
}
