package org.example.gui.controllers;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import org.example.gui.constants.LabelDisplay;
import org.example.model.DiTich;
import org.example.model.NhanVat;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.example.model.ThoiKy;
import org.example.util.TienIch;
import org.jsoup.Jsoup;

import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class ThoiKyController{
    @FXML
    private TableColumn<ThoiKy, String> colBatDau;

    @FXML
    private TableColumn<ThoiKy, Integer> colID;

    @FXML
    private TableColumn<ThoiKy, String> colKetThuc;

    @FXML
    private TableColumn<ThoiKy, String> colTen;

    @FXML
    private TextField searchTextField;

    @FXML
    private TableView<ThoiKy> tblData;

    @FXML
    private VBox vBoxInfo;

    FilteredList<ThoiKy> filteredList;

    public ThoiKyController() {
        super();
        JavaType type = new ObjectMapper().getTypeFactory().constructCollectionType(ArrayList.class, ThoiKy.class);
        var data = TienIch.<ArrayList<ThoiKy>>loadJson(type, "output/thoiky.json");
        ObservableList<ThoiKy> listNV = FXCollections.observableArrayList(data);
        this.filteredList = new FilteredList<ThoiKy>(listNV);
    }
    @FXML
    private void initialize() {
        vBoxInfo.setSpacing(5);
        colID.setCellValueFactory(
                new PropertyValueFactory<ThoiKy, Integer>("idThoiKy")
        );

        colBatDau.setCellValueFactory(
                new PropertyValueFactory<ThoiKy, String>("thoiGianBatDau")
        );

        colKetThuc.setCellValueFactory(
                new PropertyValueFactory<ThoiKy, String>("thoiGianKetThuc")
        );

        colTen.setCellValueFactory(
                new PropertyValueFactory<ThoiKy, String>("tenThoiKy")
        );

        tblData.setItems(filteredList);
        searchTextField.textProperty().addListener(
                new ChangeListener<String>() {
                    @Override
                    public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                        showFilter(newValue);
                    }
                }
        );

    }

    @FXML
    void clickItem(MouseEvent event) {
        if(event.getClickCount() > 1) {
            ThoiKy selected = tblData.getSelectionModel().getSelectedItem();
            vBoxInfo.getChildren().clear();

            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    Text text;

                    try {
                        PropertyDescriptor[] lists =  Introspector.getBeanInfo(ThoiKy.class).getPropertyDescriptors();
                        Collections.reverse(Arrays.asList(lists));
                        Field[] declaredFields = ThoiKy.class.getDeclaredFields();
                        for(Field declaredField : declaredFields) {
                            Object value = new PropertyDescriptor(declaredField.getName(), ThoiKy.class).getReadMethod().invoke(selected);
                            if(value != null && !LabelDisplay.notDisplay.contains(declaredField.getName())) {
                                // Nếu trường đó dạng danh sách
                                if(value instanceof ArrayList) {
                                   continue;
                                } else if(value instanceof String) {
                                    if(((String) value).length() > 0) {
                                        String replaceText = value.toString().replace("<br>", "\n");
                                        replaceText = replaceText.replaceAll("\\<[^>]*>","");
                                        text = new Text(LabelDisplay.labelDisPlay.get(declaredField.getName()) + ": " + replaceText);
                                        text.setStyle("-fx-font: 15 arial;");
                                        text.setLineSpacing(5);
                                        text.wrappingWidthProperty().bind(vBoxInfo.widthProperty());
                                        vBoxInfo.getChildren().addAll(text);
                                    }

                                }

                            }
                        }
                    } catch (IntrospectionException e) {
                        e.printStackTrace();
                    } catch (InvocationTargetException e) {
                        e.printStackTrace();
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    }
                }
            });

        }
    }

    void showFilter(String filter) {
        filteredList.setPredicate(item -> {
            if(filter.isEmpty()) {
                return true;
            }
            try {
                String keyword = filter.toLowerCase();
                return item.getTenThoiKy().toLowerCase().contains(keyword);

            } catch(Exception e) {
                e.printStackTrace();
            }

            return true;

        });

    }


}
