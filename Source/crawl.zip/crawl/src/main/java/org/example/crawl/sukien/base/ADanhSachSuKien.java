package org.example.crawl.sukien.base;

import org.example.model.SuKien;

import java.util.ArrayList;

public abstract class ADanhSachSuKien {
    public abstract void layDanhSachSuKien();

}