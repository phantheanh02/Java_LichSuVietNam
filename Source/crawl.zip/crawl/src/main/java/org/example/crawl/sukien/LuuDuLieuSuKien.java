package org.example.crawl.sukien;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.controller.StateController;
import org.example.crawl.nhanvat.nguoikesu.DanhSachTenNhanVat;
import org.example.crawl.sukien.thuvienlichsu.DanhSachSuKien;
import org.example.crawl.sukien.thuvienlichsu.ThongTinSuKien;
import org.example.model.NhanVat;
import org.example.model.StateCrawl;
import org.example.model.SuKien;
import org.example.util.TienIch;

import java.util.ArrayList;

public class LuuDuLieuSuKien {
    ArrayList<SuKien> listSuKien = new ArrayList<>();
    private String skFilePath = "output/sukien.json";
    private int mode = 0;
    private StateController stateController;
    private StateCrawl currentState;
    
    public LuuDuLieuSuKien(int mode) {
        if(!TienIch.checkFileExist(skFilePath)) {
            System.out.println("Lấy danh sách sự kiện");
            DanhSachSuKien danhSachSuKien = new DanhSachSuKien();
            danhSachSuKien.layDanhSachSuKien();
            return;
        }


    }

    public void start() {
        loadDanhSachSuKien();
        ThongTinSuKien thongTinSuKien = new ThongTinSuKien();
        for(int i = 0; i < listSuKien.size(); i++) {
            SuKien temp = listSuKien.get(i);
            System.out.printf("Xử lý sự kien vật có ID: %d\n", i);
            String urlPath = temp.getUrlPath();
            if(urlPath == null || urlPath.isEmpty())
                continue;

            SuKien newSuKien = thongTinSuKien.layThongTinSuKien(urlPath);
            SuKien result = gopThongTin(newSuKien, temp);
            listSuKien.set(i, result);
            TienIch.luuJson(skFilePath, listSuKien);
            System.out.printf("\tHoàn tất xử lý sự kien vật có ID: %d\n", i);
        }
    }

    private SuKien gopThongTin(SuKien sk1, SuKien sk2) {
        SuKien result = TienIch.gopObject(sk1, sk2);
        if(result == null) {
            return sk1;
        }
        return result;
    }

    private void loadDanhSachSuKien() {
        JavaType type = new ObjectMapper().getTypeFactory().constructCollectionType(ArrayList.class, SuKien.class);
        var data = TienIch.<ArrayList<SuKien>>loadJson(type, skFilePath);
        if(data != null) {
            listSuKien = data;
        } else {
            System.out.println("Không thể parse file danh sách sự kiện");
        }
    }

}
