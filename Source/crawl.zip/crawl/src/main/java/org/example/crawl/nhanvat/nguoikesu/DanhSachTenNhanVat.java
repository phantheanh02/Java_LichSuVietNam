package org.example.crawl.nhanvat.nguoikesu;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.crawl.nhanvat.base.ADanhSachTenNhanVat;
import org.example.model.NhanVat;
import org.example.model.UniqueID;
import org.example.util.TienIch;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class DanhSachTenNhanVat extends ADanhSachTenNhanVat {
    ArrayList<NhanVat> danhSachNhanVat = new ArrayList<>();
    public static void main(String[] args) {
        DanhSachTenNhanVat dsNhanVat = new DanhSachTenNhanVat();
        dsNhanVat.layDanhSachTenNhanVat();
    }

    public void luuDanhSachNhanVat() {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            new ObjectMapper().writeValue(new File("output/nhan_vat.json"), danhSachNhanVat);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @Override
    public ArrayList<NhanVat> layDanhSachTenNhanVat() {
        try {
            Document document = Jsoup.connect("https://nguoikesu.com/nhan-vat").get();
            // Lấy thông tin số trang
            Element elementTotalPage = document.select("#content > div.com-content-category-blog.blog > div.com-content-category-blog__navigation.w-100 > p").first();
            String textTotalPage = elementTotalPage.text();
            String totalPage = textTotalPage.substring(textTotalPage.indexOf("/ "));
            int value = Integer.parseInt(totalPage.replaceAll("[^0-9]", ""));
            System.out.printf("Tổng số %d trang cần lấy dữ liệu\n", value);
            for(int i = 1; i <= value; i++) {
                System.out.printf("Lấy dữ liệu trang số %d\n", i);
                int start = i * 5 - 5;
                layTenNhanVat("https://nguoikesu.com/nhan-vat?start=" + String.valueOf(start));
                System.out.printf("\t\tHoàn thành lấy tên nhân vật trang số %d\n", i);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return null;
    }

    public void layTenNhanVat(String url) {
        try {
            Document document = Jsoup.connect(url).get();
            Elements listNV = document.select("#content > div.com-content-category-blog.blog > div.com-content-category-blog__items.blog-items > div > div");
            for(Element nhanVat : listNV) {
                Element elementTenNv = nhanVat.select("div > h2 > a").first();
                NhanVat temp = new NhanVat();
                temp.setTenNhanVat(elementTenNv.text().trim());
                temp.setIdNhanVat(UniqueID.getIdNV());
                danhSachNhanVat.add(temp);
                TienIch.luuJson("output/nhan_vat.json", danhSachNhanVat);
                //System.out.println(elementTenNv.text());
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
}
