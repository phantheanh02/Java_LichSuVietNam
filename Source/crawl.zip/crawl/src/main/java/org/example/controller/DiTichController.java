package org.example.controller;

import org.example.crawl.ditich.Wikipedia.DanhSachDiTichLichSu;

public class DiTichController {
    public void start() {
        DanhSachDiTichLichSu danhSachDiTichLichSu = new DanhSachDiTichLichSu();
        danhSachDiTichLichSu.layDanhSachDiTich();
    }
}
