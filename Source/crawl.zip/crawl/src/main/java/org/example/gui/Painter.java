package org.example.gui;

import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.*;

public class Painter extends Application {

    @FXML
    private Tab tabNhanVat;

    @FXML
    private TabPane tabPane;

    @FXML
    private void initialize() {

    }

    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/views/Painter.fxml"));
        Scene scene = new Scene(root);
        stage.setTitle("Lịch sử Việt Nam");
        stage.setScene(scene);
        stage.show();

    }

    public static void main(String[] args) {
        launch(args);
    }


}
