package org.example.gui.constants;

import java.util.ArrayList;
import java.util.HashMap;

public class LabelDisplay {
    public static HashMap<String, String> labelDisPlay = new HashMap<String, String>();
    public static ArrayList<String> notDisplay = new ArrayList<>();
    static {
        // Nhân vật
        labelDisPlay.put("tenNhanVat", "Tên");
        labelDisPlay.put("namSinh", "Sinh");
        labelDisPlay.put("namMat", "Mất");
        labelDisPlay.put("tenCha", "Cha");
        labelDisPlay.put("tenMe", "Mẹ");
        labelDisPlay.put("chucVu", "Chức vụ");
        labelDisPlay.put("idThoiKy", "Thời kỳ");
        labelDisPlay.put("description", "Thông tin");

        // Chức vụ
        labelDisPlay.put("ten", "Tên");
        labelDisPlay.put("taiVi", "Tại Vị");
        labelDisPlay.put("tienNhiem", "Tiền nhiệm");
        labelDisPlay.put("keNhiem", "Kế nhiệm");
        labelDisPlay.put("nhiemKy", "Nhiệm Kỳ");

        // Thời Kỳ
        labelDisPlay.put("tenThoiKy", "Tên thời kì");
        labelDisPlay.put("thoiGianBatDau", "Thời gian bắt đầu");
        labelDisPlay.put("thoiGianKetThuc", "Thời gian kết thúc");
        labelDisPlay.put("moTa", "Mô tả");

        // Di Tích
        labelDisPlay.put("diaDiem", "Địa điểm");

        // Lễ hội
        labelDisPlay.put("thoiGian", "Thời gian");

        // Sự kiện
        labelDisPlay.put("idSuKien", "Sự kiện");
        labelDisPlay.put("tenSuKien", "Tên sự kiện");
        labelDisPlay.put("thoiDiemBatDau", "Bắt đầu");
        labelDisPlay.put("thoiDiemKetThuc", "Kết thúc");
        labelDisPlay.put("nhanVatLienQuan", "Nhân vật liên quan");
        // Danh sách không hiển thị
        notDisplay.add("urlPath");
        notDisplay.add("image");
        notDisplay.add("idNhanVat");
        notDisplay.add("hinhAnh");
    }
}
