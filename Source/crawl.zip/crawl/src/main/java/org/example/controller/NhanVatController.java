package org.example.controller;

import org.example.crawl.nhanvat.LuuDuLieuNV;
import org.example.util.TienIch;

import java.util.Scanner;

public class NhanVatController {
    public int start() {
        int code = -1;
        menu();
        code = luaChon();
        return code;
    }

    public void menu() {
        System.out.println("\t Vui lòng lựa chọn: ");
        System.out.println("\t\t 1. Tiếp tục quá trình cào dữ liệu");
        System.out.println("\t\t 2. Cào lại từ đầu");
        System.out.println("\t\t 0. Quay lại menu ");
        System.out.print("Lựa chọn của bạn: ");
    }

    public int luaChon() {
        Scanner sc = new Scanner(System.in);
        int value = sc.nextInt();
        switch (value) {
            case 0:
                break;
            case 1:
                tiepTucCaoDuLieu();
                break;
            case 2:
                caoTuDau();
                break;
        }

        return value;
    }

    private void tiepTucCaoDuLieu()
    {
        if(!TienIch.checkFileExist("save_state/state.json")) {
            System.out.println("Không phát hiện trạng thái cào dữ liệu trước đó");
            System.out.println("Tiến hành cào lại từ đầu");
            caoTuDau();
            return;
        }

        LuuDuLieuNV nv = new LuuDuLieuNV(1);
        nv.start();

    }

    private void caoTuDau()
    {
        LuuDuLieuNV nv = new LuuDuLieuNV(0);
        nv.start();
    }


}
