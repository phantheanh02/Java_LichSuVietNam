package org.example.crawl.lehoi.wikipedia;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.example.crawl.lehoi.base.ADanhSachLeHoi;
import org.example.model.LeHoi;
import org.example.util.TienIch;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;

import static org.example.model.UniqueID.getIdLeHoi;


public class DanhSachTenLeHoi extends ADanhSachLeHoi {
    ArrayList<LeHoi> danhSachLeHoi = new ArrayList<>();
    private Document htmlPage;
    private String leHoiOutput = "output/le_hoi.json";

    public DanhSachTenLeHoi() {
        danhSachLeHoi = new ArrayList<>();
        layHTML();
    }
    @Override
    public ArrayList<LeHoi> danhSachLeHoi() {
        System.out.println("Lưu dữ liệu danh sách lễ hội");
        int index = 0;
        Elements thongTinLeHois = htmlPage.select("#mw-content-text > div.mw-parser-output > table.prettytable.wikitable > tbody > tr");
        for (Element tmp : thongTinLeHois) {
            if(index++ < 1) continue;
            int id = getIdLeHoi();
            System.out.printf("Xử lý Lễ Hội số: %d\n", id);
            Elements thuocTinhLeHois = tmp.select(" > td");
            int index1 = 0;
            LeHoi leHoi = new LeHoi();
            for(Element thuocTinhLeHoi : thuocTinhLeHois){
                if(index1++ > 2) break;
                if(index1 == 1) leHoi.setThoiGian(thuocTinhLeHoi.text());
                if(index1 == 2) leHoi.setDiaDiem(thuocTinhLeHoi.text());
                if(index1 == 3){
                    leHoi.setTen(thuocTinhLeHoi.text());
                    Element linkMoTa = thuocTinhLeHoi.selectFirst("> a");
                    if (linkMoTa != null) {
                        String moTa = linkMoTa.attr("href").substring(6);
                        leHoi.setMoTa(layMoTa(TienIch.layDuongDanWikiApiTuTenDoiTuong(moTa)));
                    }
                }
            }
            leHoi.setId(id);
            danhSachLeHoi.add(leHoi);
            TienIch.luuJson(leHoiOutput, danhSachLeHoi);
            System.out.printf("\tHoàn thành xử lý Lễ Hội số: %d\n", id);
        }
        return danhSachLeHoi;
    }


    /**
     * Lấy đường dẫn HTML
     */
    public void layHTML() {
        try {
            htmlPage = Jsoup.connect("https://vi.wikipedia.org/wiki/L%E1%BB%85_h%E1%BB%99i_Vi%E1%BB%87t_Nam?fbclid=IwAR3l4Ciwtp4ZVF6yMgnwKZ4cy4pLVVB1jFj5DtjT0G5FcAjtQJEhCRrSO74#Danh_s%C3%A1ch_m%E1%BB%99t_s%E1%BB%91_l%E1%BB%85_h%E1%BB%99i").get();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Call API lấy data Json
     * @param url
     * @return
     */
    private String layJsonData(String url) {
        // Tạo request
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .build();
        Response response = null;
        try {
            response = client.newCall(request).execute();
            return response.body().string();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Lấy phần mô tả
     * @param url
     * @return
     */
    private String layMoTa(String url) {
        String extract = null;
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode extractNode;
        //Trong 1 số trường hợp, 1 vài link lễ hội chưa được cập nhật thông tin trên wiki mà chỉ có trang trắng, hoặc đường dẫn bằng bên bị sai cú pháp (lỗi do web)
        //vì vậy json sẽ không có cấu trúc thông thường của wikiApi. Do đó sẽ xảy ra hiện tượng đường dẫn là null khi truy cập vào các trường, từ đó gây ra lỗi
        try {
            JsonNode rootNode = objectMapper.readTree(layJsonData(url));
            JsonNode pagesNode = rootNode.path("query").path("pages").get(0);
            //Nếu pagesNode khác null thì tiếp tục select và trường "extract"
            if (pagesNode != null) {
                extractNode = pagesNode.path("extract");
                extract = extractNode.asText();
            }
        } catch (JsonProcessingException e) {
            // Log error or do something else
            return null;
        }
        return extract;
    }


}
