package org.example.gui.controllers;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import org.example.gui.constants.LabelDisplay;
import org.example.model.DiTich;
import org.example.model.LeHoi;
import org.example.model.NhanVat;
import javafx.collections.transformation.FilteredList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.example.model.ThoiKy;
import org.example.util.TienIch;
import org.jsoup.Jsoup;

import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class LeHoiController{
    @FXML
    private TableColumn<LeHoi, String> colDiaDiem;

    @FXML
    private TableColumn<LeHoi, Integer> colID;

    @FXML
    private TableColumn<LeHoi, String> colThoiGian;

    @FXML
    private TableColumn<LeHoi, String> colTen;

    @FXML
    private TextField searchTextField;

    @FXML
    private TableView<LeHoi> tblData;

    @FXML
    private VBox vBoxInfo;

    FilteredList<LeHoi> filteredList;

    public LeHoiController() {
        super();
        JavaType type = new ObjectMapper().getTypeFactory().constructCollectionType(ArrayList.class, LeHoi.class);
        var data = TienIch.<ArrayList<LeHoi>>loadJson(type, "output/le_hoi.json");
        ObservableList<LeHoi> listNV = FXCollections.observableArrayList(data);
        this.filteredList = new FilteredList<LeHoi>(listNV);
    }
    @FXML
    private void initialize() {
        vBoxInfo.setSpacing(5);
        colID.setCellValueFactory(
                new PropertyValueFactory<LeHoi, Integer>("id")
        );

        colDiaDiem.setCellValueFactory(
                new PropertyValueFactory<LeHoi, String>("diaDiem")
        );

        colThoiGian.setCellValueFactory(
                new PropertyValueFactory<LeHoi, String>("thoiGian")
        );

        colTen.setCellValueFactory(
                new PropertyValueFactory<LeHoi, String>("ten")
        );

        tblData.setItems(filteredList);
        searchTextField.textProperty().addListener(
                new ChangeListener<String>() {
                    @Override
                    public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                        showFilter(newValue);
                    }
                }
        );

    }

    @FXML
    void clickItem(MouseEvent event) {
        if(event.getClickCount() > 1) {
            LeHoi selected = tblData.getSelectionModel().getSelectedItem();
            vBoxInfo.getChildren().clear();

            Platform.runLater(new Runnable() {
                @Override
                public void run() {
                    Text text;

                    try {
                        PropertyDescriptor[] lists =  Introspector.getBeanInfo(LeHoi.class).getPropertyDescriptors();
                        Collections.reverse(Arrays.asList(lists));
                        Field[] declaredFields = LeHoi.class.getDeclaredFields();
                        for(Field declaredField : declaredFields) {
                            Object value = new PropertyDescriptor(declaredField.getName(), LeHoi.class).getReadMethod().invoke(selected);
                            if(value != null && !LabelDisplay.notDisplay.contains(declaredField.getName())) {
                                // Nếu trường đó dạng danh sách
                                if(value instanceof ArrayList) {
                                    continue;
                                } else if(value instanceof String) {
                                    if(((String) value).length() > 0) {
                                        text = new Text(LabelDisplay.labelDisPlay.get(declaredField.getName()) + ": " + value.toString());
                                        text.setStyle("-fx-font: 15 arial;");
                                        text.setLineSpacing(5);
                                        text.wrappingWidthProperty().bind(vBoxInfo.widthProperty());
                                        vBoxInfo.getChildren().addAll(text);
                                    }

                                }

                            }
                        }
                    } catch (IntrospectionException e) {
                        e.printStackTrace();
                    } catch (InvocationTargetException e) {
                        e.printStackTrace();
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    }
                }
            });

        }
    }

    void showFilter(String filter) {
        filteredList.setPredicate(item -> {
            if(filter.isEmpty()) {
                return true;
            }
            try {
                String keyword = filter.toLowerCase();
                return item.getTen().toLowerCase().contains(keyword);

            } catch(Exception e) {
                e.printStackTrace();
            }

            return true;

        });

    }


}
