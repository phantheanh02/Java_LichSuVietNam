package org.example.crawl.thoiky;

import org.example.crawl.sukien.LuuDuLieuSuKien;
import org.example.crawl.sukien.thuvienlichsu.DanhSachSuKien;
import org.example.crawl.sukien.thuvienlichsu.ThongTinSuKien;
import org.example.crawl.thoiky.vansu.DanhSachThoiKy;
import org.example.model.SuKien;
import org.example.model.ThoiKy;
import org.example.util.TienIch;

import java.util.ArrayList;

public class LuuDuLieuThoiKy {
    private ArrayList<ThoiKy> listThoiKy = new ArrayList<>();

    private String tkFilePath = "output/thoiky.json";
    public void start() {
        DanhSachThoiKy danhSachThoiKy = new DanhSachThoiKy();
        listThoiKy = danhSachThoiKy.layDanhSachThoiKy();
        TienIch.luuJson(tkFilePath, listThoiKy);
    }


}
