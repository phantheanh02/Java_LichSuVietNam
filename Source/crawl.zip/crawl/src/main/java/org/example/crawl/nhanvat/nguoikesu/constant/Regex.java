package org.example.crawl.nhanvat.nguoikesu.constant;

public class Regex {
    public static String regexCha1 = "Cha (.*?)[\\,\\.]";
    public static String regexMe1 = "mẹ là (.*?)[\\,\\.]";
    public static String regexMe2 = "mẹ ông là (.*?)[\\,\\.]";
    public static String regexChaWiki = "cha =(.*?)\\n";
    public static String regexMeWiki = "mẹ =(.*?)\\n";
    public static String regexNamSinh = "sinh = (.*?)\\n";
    public static String regexNamMat = "mất = (.*?)\\n";
    public static String regexSinhDes1 = "\\((.*?)[-–]";
    public static String regexSinhDes2 = "(sinh năm \\d+)\\)";
    public static String regexRemove = "(.*?) \\d";
    public static String regexMatDes = "[-–](.*?)\\)";
}
